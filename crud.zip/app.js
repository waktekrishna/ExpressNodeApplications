const { response, request } = require('express');
const express = require('express');

const app = express();
app.use(express.json());

app.listen(3000, Server);
function Server(request, response)
{
    console.log("Server is started...@3000.");
}

const details = [
    {id: 1, name : "ramesh", subject : "Angular"},
    {id: 2, name : "suresh", subject : "Java"},
    {id: 3, name : "mahesh",  subject : "Python"}
];

app.get('/getSubjects',Details);
function Details(request, response)
{
    response.send(details);
}


app.get('/getSubjects/:id',SubjectswithID);

function SubjectswithID(request, response)
{
    var i = 0;

    for(i = 0; i < details.length; i++)
    {
        if (details[i].id == request.params.id)
            break;
    }
    
    if(i !==  details.length)
    {
        response.send(details[i])
    }
    else
    {
        response.status(404).send("There is no such detail");
    }
}

app.post('/details', (request, response) => {
    const detail = {
        id: details.length+1,
        name : request.body.name,
        subject : request.body.subject
    }

    details.push(detail);
    response.send(detail);
});

app.put('/getSubjects/:id', (request, response) => {
    var i = 0;

    for(i = 0; i < details.length; i++)
    {
        if (details[i].id == request.params.id)
            break;
    }
    
    if(i !==  details.length)
    {
        details[i].name = request.body.name;
        details[i].subject = request.body.subject;
        response.send(details[i]);

   }
    else
    {
        response.status(404).send("There is no such Subject");
    }
});

app.delete('/getSubjects/:id', (request, response) => {
    var i = 0;

    for(i = 0; i < details.length; i++)
    {
        if (details[i].id == request.params.id)
            break;
    }
    
    if(i ==  details.length)
    {
        response.status(404).send("There is no such batch");
   }
    else
    {
        details.splice(i,1);
        response.send(details);
    }
});